/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package USC_Booking;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author getna
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({USC_Booking.GrpExerciseIT.class, USC_Booking.ModifyBookingIT.class, USC_Booking.ReviewClassIT.class, USC_Booking.ChampionClassIT.class, USC_Booking.UniversitySportsCentreIT.class, USC_Booking.MonthlyReportIT.class})
public class USC_BookingITSuite {

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
}
